var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./AutoaddressSearchComponent/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./AutoaddressSearchComponent/index.ts":
/*!*********************************************!*\
  !*** ./AutoaddressSearchComponent/index.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.AutoaddressSearchComponent = void 0;\n\nvar AutoaddressSearchComponent =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function AutoaddressSearchComponent() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  AutoaddressSearchComponent.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _this = this;\n\n    var _a, _b; // bind methods to global context so they can be accessed outside of component\n\n\n    this._notifyOutputChanged = notifyOutputChanged.bind(this);\n    this._setAddress = this.setAddress.bind(this);\n    this._setEcadData = this.setEcadData.bind(this);\n	this._setUkadData = this.setUkadData.bind(this);\n    this._setElements = this.setElements.bind(this);\n    this._toggleCountry = this.toggleCountry.bind(this); // set global variables\n\n    this.licencekey = (_a = context.parameters.licencekey.raw) !== null && _a !== void 0 ? _a : '';\n    this.addressProfile = (_b = context.parameters.addressprofile.raw) !== null && _b !== void 0 ? _b : '';\n    var guid = Date.now();\n    this.controlId = 'aa-control-' + guid; // context.mode.contextInfo.entityId\n    // PCF Enum raw does not return value. Have to cast as number and match to correct country\n\n    switch (context.parameters.defaultCountry.raw) {\n      case \"0\":\n        this.countrySetting = 'ie';\n        break;\n\n      case \"1\":\n        this.countrySetting = 'ni';\n        break;\n\n      case \"2\":\n        this.countrySetting = 'gb';\n        break;\n\n      default:\n        this.countrySetting = 'ie';\n        break;\n    }\n\n    this.country = this.countrySetting.toUpperCase();\n\n    switch (context.parameters.countrySelectOn.raw) {\n      case \"0\":\n        this.countrySelectOn = true;\n        break;\n\n      case \"1\":\n        this.countrySelectOn = false;\n        break;\n\n      default:\n        this.countrySelectOn = false;\n        break;\n    }\n\n    if ('undefined' == typeof window.jQuery) {\n      // append jQuery script to head\n      var jqsUrl = \"https://code.jquery.com/jquery-3.5.1.min.js\";\n      var jqsNode = document.createElement(\"script\");\n      jqsNode.setAttribute(\"type\", \"text/javascript\");\n      jqsNode.setAttribute(\"integrity\", \"sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=\");\n      jqsNode.setAttribute(\"crossorigin\", \"anonymous\");\n      jqsNode.setAttribute(\"src\", jqsUrl);\n      jqsNode.addEventListener('load', function () {\n        return _this._setElements('jQueryScript');\n      });\n      document.head.appendChild(jqsNode);\n    } else {\n      this.setElements('jQueryScript');\n    } // append Autoaddress script to head\n\n\n    var scriptUrl = \"https://api.autoaddress.ie/2.0/control/js/jquery.autoaddress.min.js\";\n    var scriptNode = document.createElement(\"script\");\n    scriptNode.setAttribute(\"type\", \"text/javascript\");\n    scriptNode.setAttribute(\"src\", scriptUrl);\n    scriptNode.addEventListener('load', function () {\n      return _this._setElements('aaScript');\n    });\n    document.head.appendChild(scriptNode);\n    var cssUrl = \"https://api.autoaddress.ie/2.0/control/css/autoaddress.min.css\"; // append Autoaddress css to head\n\n    var cssNode = document.createElement(\"link\");\n    cssNode.setAttribute(\"rel\", \"stylesheet\");\n    cssNode.setAttribute(\"text\", \"text/css\");\n    cssNode.setAttribute(\"href\", cssUrl);\n    document.head.appendChild(cssNode); // create html container for control\n\n    this._container = document.createElement(\"div\"); // create element to attach Autoaddress jQuery to \n\n    this.searchBox = document.createElement(\"div\");\n    this.searchBox.setAttribute(\"id\", this.controlId);\n    this.searchBox.setAttribute(\"class\", \"aa-control\");\n\n    this._container.appendChild(this.searchBox); // create element to toggle country\n\n\n    if (this.countrySelectOn) {\n      var countryLabel = document.createElement(\"label\");\n      countryLabel.setAttribute(\"for\", \"country-select\");\n      countryLabel.innerHTML = \"Country Select\";\n      var countries = [\"IE\", \"NI\", \"GB\"];\n      this.countryToggle = document.createElement(\"select\");\n      this.countryToggle.setAttribute(\"id\", \"country-select\");\n      countries.forEach(function (country) {\n        var option = document.createElement(\"option\");\n        option.value = country;\n        option.text = country;\n\n        _this.countryToggle.appendChild(option);\n      });\n      this.countryToggle.value = this.countrySetting.toUpperCase();\n      this.countryToggle.onchange = this._toggleCountry; // this._container.appendChild(this.countryToggle); \n\n      this._container.insertBefore(this.countryToggle, this.searchBox);\n\n      this._container.insertBefore(countryLabel, this.countryToggle);\n    } // append global container to instanced container\n\n\n    container.appendChild(this._container); // set the autoaddress control on the element\n    // wait one second for jQuery to load in header\n    // setTimeout(() => {\n    //     this.configurejQueryElements();\n    // }, 200);\n  };\n\n  AutoaddressSearchComponent.prototype.setElements = function (scriptSet) {\n    console.log('setElements script: ', scriptSet);\n\n    if (scriptSet == 'aaScript') {\n      this.aaLoaded = true;\n    }\n\n    if (scriptSet == 'jQueryScript') {\n      this.jQueryLoaded = true;\n    }\n\n    if (this.jQueryLoaded && this.aaLoaded) {\n      this.configurejQueryElements();\n    }\n  };\n\n  AutoaddressSearchComponent.prototype.configurejQueryElements = function () {\n    $('#' + this.controlId).AutoAddress({\n      key: this.licencekey,\n      vanityMode: true,\n      addressProfile: this.addressProfile,\n      country: this.countrySetting,\n      language: \"en\",\n      autocompleteMinChars: 3,\n      optionsLimit: -1,\n      incompleteAddressLabel: \"\",\n      addressFoundLabel: \"\",\n      partialAddressLabel: \"\",\n      nuaAddressFoundLabel: \"\",\n      noResultFoundLabel: \"\",\n      errorMessageLabel: \"\",\n      width: \"auto\",\n      hoverOptionPanel: true,\n      onAddressFound: this._setAddress\n    });\n    $('.autoaddress-text-box').attr('autocomplete', 'no');\n  };\n\n  AutoaddressSearchComponent.prototype.getEcadData = function (licencekey, ecadId, transactionId) {\n    var aaEcadEndPoint = \"https://api.autoaddress.ie/2.0/getecaddata?\";\n    return fetch(aaEcadEndPoint + \"ecadId=\" + ecadId + \"&key=\" + licencekey + \"&txn=\" + transactionId).then(function (res) {\n        return res.json();\n    }).then(function (res) {\n        return res;\n    });\n  };\n\n  \n\n  AutoaddressSearchComponent.prototype.getUkadData = function (licencekey, postcode, transactionId) {\n    var aaGBEndPoint = \"https://api.autoaddress.ie/2.0/getGBPostcodeData?\";\n    return fetch(aaGBEndPoint + \"postcode=\" + postcode + \"&key=\" + licencekey + \"&txn=\" + transactionId).then(function (res) {\n        return res.json();\n    }).then(function (res) {\n        return res;\n    });\n};\n\n  AutoaddressSearchComponent.prototype.setAddress = function (result) {\n    var _this = this;\n\n    this.line1 = result.reformattedAddress[0];\n    this.line2 = result.reformattedAddress[1];\n    this.line3 = result.reformattedAddress[2];\n    this.line4 = result.reformattedAddress[3];\n    this.line5 = result.reformattedAddress[4];\n    this.postcode = result.postcode;\n\n    if (result.addressId != null) {\n		if (this.country === 'IE') {\n			this.getEcadData(this.licencekey, result.addressId, result.input.txn).then(function (response) {\n				_this._setEcadData(response); // call notifyOutputChanged to update output values and tell context to refresh fields\n				_this._notifyOutputChanged();\n			});\n		}\n		else if (result.postcode !== null && this.country !== 'IE') {\n			this.getUkadData(this.licencekey, result.postcode, result.input.txn).then(function (response) {\n				_this._setUkadData(response); // call notifyOutputChanged to update output values and tell context to refresh fields\n				_this._notifyOutputChanged();\n			});\n		}\n    }\n  };\n\n  AutoaddressSearchComponent.prototype.setEcadData = function (result) {\n    this.laId = result.administrativeInfo.laId == undefined ? \"\" : result.administrativeInfo.laId.toString();\n    this.latitude = result.spatialInfo.etrs89.location.latitude == 'undefined' ? \"\" : result.spatialInfo.etrs89.location.latitude.toString();\n    this.longitude = result.spatialInfo.etrs89.location.longitude == 'undefined' ? \"\" : result.spatialInfo.etrs89.location.longitude.toString();\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n   \n\n  AutoaddressSearchComponent.prototype.setUkadData = function (result) {    \n\n    this.latitude = result.spatialInfo.wgs84.location.latitude == 'undefined' ? \"\" : result.spatialInfo.wgs84.location.latitude.toString();\n\n    this.longitude = result.spatialInfo.wgs84.location.longitude == 'undefined' ? \"\" : result.spatialInfo.wgs84.location.longitude.toString();\n\n  };\n\n  /**\r\n\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n\n   */\n\n\n  AutoaddressSearchComponent.prototype.updateView = function (context) {// Add code to update control view\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  AutoaddressSearchComponent.prototype.getOutputs = function () {\n    return {\n      line1: this.line1,\n      line2: this.line2,\n      line3: this.line3,\n      line4: this.line4,\n      line5: this.line5,\n      postcode: this.postcode,\n      country: this.country,\n      laId: this.laId,\n      latitude: this.latitude,\n      longitude: this.longitude\n    };\n  };\n\n  AutoaddressSearchComponent.prototype.toggleCountry = function () {\n    console.log();\n    var countryValue = $(\"#country-select\").val();\n    $('#' + this.controlId).AutoAddress().setCountry(countryValue);\n\n    if (countryValue) {\n      this.country = countryValue.toString().toUpperCase();\n    }\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  AutoaddressSearchComponent.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return AutoaddressSearchComponent;\n}();\n\nexports.AutoaddressSearchComponent = AutoaddressSearchComponent;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./AutoaddressSearchComponent/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('AutoaddressNamespace.AutoaddressSearchComponent', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AutoaddressSearchComponent);
} else {
	var AutoaddressNamespace = AutoaddressNamespace || {};
	AutoaddressNamespace.AutoaddressSearchComponent = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AutoaddressSearchComponent;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}