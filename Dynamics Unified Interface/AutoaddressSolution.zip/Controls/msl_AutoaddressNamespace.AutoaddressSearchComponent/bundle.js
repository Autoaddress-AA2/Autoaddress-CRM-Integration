var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./AutoaddressSearchComponent/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./AutoaddressSearchComponent/index.ts":
/*!*********************************************!*\
  !*** ./AutoaddressSearchComponent/index.ts ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {value: true});
exports.AutoaddressSearchComponent = void 0;

var AutoaddressSearchComponent =
/** @class */
function () {
/**r
 * Empty constructor.r
 */
function AutoaddressSearchComponent() {}
/**r
 * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.r
 * Data-set values are not initialized here, use updateView.r
 * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.r
 * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.r
 * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.r
 * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.r
 */


AutoaddressSearchComponent.prototype.init = function (context, notifyOutputChanged, state, container) {
	var _this = this;

	var _a, _b; // bind methods to global context so they can be accessed outside of component


	this._notifyOutputChanged = notifyOutputChanged.bind(this);
	this._setAddress = this.setAddress.bind(this);
	this._setEcadData = this.setEcadData.bind(this);
	this._setUkadData = this.setUkadData.bind(this);
	this._setElements = this.setElements.bind(this);
	this._toggleCountry = this.toggleCountry.bind(this); // set global variables

	this.licencekey = (_a = context.parameters.licencekey.raw) !== null && _a !== void 0 ? _a : '';
	this.addressProfile = (_b = context.parameters.addressprofile.raw) !== null && _b !== void 0 ? _b : '';
	var guid = Date.now();
	this.controlId = 'aa-control-' + guid; // context.mode.contextInfo.entityId
	// PCF Enum raw does not return value. Have to cast as number and match to correct country

	switch (context.parameters.defaultCountry.raw) {
	case "0":
		this.countrySetting = 'ie';
		break;

	case "1":
		this.countrySetting = 'ni';
		break;

	case "2":
		this.countrySetting = 'gb';
		break;

	default:
		this.countrySetting = 'ie';
		break;
	}

	this.country = this.countrySetting.toUpperCase();

	switch (context.parameters.countrySelectOn.raw) {
	case "0":
		this.countrySelectOn = true;
		break;

	case "1":
		this.countrySelectOn = false;
		break;

	default:
		this.countrySelectOn = false;
		break;
	}

	if ('undefined' == typeof window.jQuery) {
	// append jQuery script to head
	var jqsUrl = "https://code.jquery.com/jquery-3.5.1.min.js";
	var jqsNode = document.createElement("script");
	jqsNode.setAttribute("type", "text/javascript");
	jqsNode.setAttribute("integrity", "sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=");
	jqsNode.setAttribute("crossorigin", "anonymous");
	jqsNode.setAttribute("src", jqsUrl);
	jqsNode.addEventListener('load', function () {
		return _this._setElements('jQueryScript');
	});
	document.head.appendChild(jqsNode);
	} else {
	this.setElements('jQueryScript');
	} // append Autoaddress script to head


	var scriptUrl = "https://api.autoaddress.ie/2.0/control/js/jquery.autoaddress.min.js";
	var scriptNode = document.createElement("script");
	scriptNode.setAttribute("type", "text/javascript");
	scriptNode.setAttribute("src", scriptUrl);
	scriptNode.addEventListener('load', function () {
	return _this._setElements('aaScript');
	});
	document.head.appendChild(scriptNode);
	var cssUrl = "https://api.autoaddress.ie/2.0/control/css/autoaddress.min.css"; // append Autoaddress css to head

	var cssNode = document.createElement("link");
	cssNode.setAttribute("rel", "stylesheet");
	cssNode.setAttribute("text", "text/css");
	cssNode.setAttribute("href", cssUrl);
	document.head.appendChild(cssNode); // create html container for control

	this._container = document.createElement("div"); // create element to attach Autoaddress jQuery to 

	this.searchBox = document.createElement("div");
	this.searchBox.setAttribute("id", this.controlId);
	this.searchBox.setAttribute("class", "aa-control");

	this._container.appendChild(this.searchBox); // create element to toggle country


	if (this.countrySelectOn) {
	var countryLabel = document.createElement("label");
	countryLabel.setAttribute("for", "country-select");
	countryLabel.innerHTML = "Country Select";
	var countries = ["IE", "NI", "GB"];
	this.countryToggle = document.createElement("select");
	this.countryToggle.setAttribute("id", "country-select");
	countries.forEach(function (country) {
		var option = document.createElement("option");
		option.value = country;
		option.text = country;

		_this.countryToggle.appendChild(option);
	});
	this.countryToggle.value = this.countrySetting.toUpperCase();
	this.countryToggle.onchange = this._toggleCountry; // this._container.appendChild(this.countryToggle); 

	this._container.insertBefore(this.countryToggle, this.searchBox);

	this._container.insertBefore(countryLabel, this.countryToggle);
	} // append global container to instanced container


	container.appendChild(this._container); // set the autoaddress control on the element
	// wait one second for jQuery to load in header
	// setTimeout(() => {
	//     this.configurejQueryElements();
	// }, 200);
};

AutoaddressSearchComponent.prototype.setElements = function (scriptSet) {
	console.log('setElements script: ', scriptSet);

	if (scriptSet == 'aaScript') {
	this.aaLoaded = true;
	}

	if (scriptSet == 'jQueryScript') {
	this.jQueryLoaded = true;
	}

	if (this.jQueryLoaded && this.aaLoaded) {
	this.configurejQueryElements();
	}
};

AutoaddressSearchComponent.prototype.configurejQueryElements = function () {
	$('#' + this.controlId).AutoAddress({
	key: this.licencekey,
	vanityMode: true,
	addressProfile: this.addressProfile,
	country: this.countrySetting,
	language: "en",
	autocompleteMinChars: 3,
	optionsLimit: -1,
	incompleteAddressLabel: "",
	addressFoundLabel: "",
	partialAddressLabel: "",
	nuaAddressFoundLabel: "",
	noResultFoundLabel: "",
	errorMessageLabel: "",
	width: "auto",
	hoverOptionPanel: true,
	onAddressFound: this._setAddress
	});
	$('.autoaddress-text-box').attr('autocomplete', 'no');
};

AutoaddressSearchComponent.prototype.getEcadData = function (licencekey, ecadId, transactionId) {
	var aaEcadEndPoint = "https://api.autoaddress.ie/2.0/getecaddata?";
	return fetch(aaEcadEndPoint + "ecadId=" + ecadId + "&key=" + licencekey + "&txn=" + transactionId).then(function (res) {
		return res.json();
	}).then(function (res) {
		return res;
	});
};



AutoaddressSearchComponent.prototype.getUkadData = function (licencekey, postcode, transactionId) {
	var aaGBEndPoint = "https://api.autoaddress.ie/2.0/getGBPostcodeData?";
	return fetch(aaGBEndPoint + "postcode=" + postcode + "&key=" + licencekey + "&txn=" + transactionId).then(function (res) {
		return res.json();
	}).then(function (res) {
		return res;
	});
};

AutoaddressSearchComponent.prototype.setAddress = function (result) {
	var _this = this;

	this.line1 = result.reformattedAddress[0];
	this.line2 = result.reformattedAddress[1];
	this.line3 = result.reformattedAddress[2];
	this.line4 = result.reformattedAddress[3];
	this.line5 = result.reformattedAddress[4];
	this.postcode = result.postcode;

	if (result.addressId != null) {
		if (this.country === 'IE') {
			this.getEcadData(this.licencekey, result.addressId, result.input.txn).then(function (response) {
				_this._setEcadData(response); // call notifyOutputChanged to update output values and tell context to refresh fields
				_this._notifyOutputChanged();
			});
		}
		else if (result.postcode !== null && this.country !== 'IE') {
			this.getUkadData(this.licencekey, result.postcode, result.input.txn).then(function (response) {
				_this._setUkadData(response); // call notifyOutputChanged to update output values and tell context to refresh fields
				_this._notifyOutputChanged();
			});
		}
	}
};

AutoaddressSearchComponent.prototype.setEcadData = function (result) {
	this.laId = result.administrativeInfo.laId == undefined ? "" : result.administrativeInfo.laId.toString();
	this.latitude = result.spatialInfo.etrs89.location.latitude == 'undefined' ? "" : result.spatialInfo.etrs89.location.latitude.toString();
	this.longitude = result.spatialInfo.etrs89.location.longitude == 'undefined' ? "" : result.spatialInfo.etrs89.location.longitude.toString();
};
/**r
 * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.r
 * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functionsr
 */

	

AutoaddressSearchComponent.prototype.setUkadData = function (result) {    

	this.latitude = result.spatialInfo.wgs84.location.latitude == 'undefined' ? "" : result.spatialInfo.wgs84.location.latitude.toString();

	this.longitude = result.spatialInfo.wgs84.location.longitude == 'undefined' ? "" : result.spatialInfo.wgs84.location.longitude.toString();

};

/**r
 
	* Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.r

	* @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functionsr

	*/


AutoaddressSearchComponent.prototype.updateView = function (context) {// Add code to update control view
};
/**r
 * It is called by the framework prior to a control receiving new data.r
 * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”r
 */


AutoaddressSearchComponent.prototype.getOutputs = function () {
	return {
	line1: this.line1,
	line2: this.line2,
	line3: this.line3,
	line4: this.line4,
	line5: this.line5,
	postcode: this.postcode,
	country: this.country,
	laId: this.laId,
	latitude: this.latitude,
	longitude: this.longitude
	};
};

AutoaddressSearchComponent.prototype.toggleCountry = function () {
	console.log();
	var countryValue = $("#country-select").val();
	$('#' + this.controlId).AutoAddress().setCountry(countryValue);

	if (countryValue) {
	this.country = countryValue.toString().toUpperCase();
	}
};
/**r
 * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.r
 * i.e. cancelling any pending remote calls, removing listeners, etc.r
 */


AutoaddressSearchComponent.prototype.destroy = function () {// Add code to cleanup control if necessary
};

return AutoaddressSearchComponent;
}();

exports.AutoaddressSearchComponent = AutoaddressSearchComponent;

//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./AutoaddressSearchComponent/index.ts?

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('AutoaddressNamespace.AutoaddressSearchComponent', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AutoaddressSearchComponent);
} else {
	var AutoaddressNamespace = AutoaddressNamespace || {};
	AutoaddressNamespace.AutoaddressSearchComponent = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AutoaddressSearchComponent;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}