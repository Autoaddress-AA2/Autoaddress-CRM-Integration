<?php
  
function table_creator()
{
	global $wpdb;
	$table_name= $wpdb->prefix."autoaddress";	
	/*Creat a table*/
	$sql_table="CREATE TABLE IF NOT EXISTS $table_name(
	add_profile varchar(100),
	lic_key  varchar(100),
	billing_company varchar(100),
	billing_addressline1 varchar(100),
	billing_addressline2  varchar(100),
	billing_city varchar(100),
	billing_county varchar(100),
	billing_eircode varchar(100),
	delivery_company varchar(100),
	delivery_addressline1 varchar(100),
	delivery_addressline2 varchar(100),
	delivery_city varchar(100),
	delivery_county varchar(100),
	delivery_eircode varchar(100),
	created_date DATETIME
	)";	
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	dbDelta($sql_table);
	add_option("my_plugin_db_version");
	
	$success = $wpdb->insert("$table_name", array(
		"add_profile" => 'Wordpress-Autoaddress Plugin',
		"lic_key" => $lic_key,
		"billing_company" => 'billing_company',
		"billing_addressline1" => 'billing_address_1',
		"billing_addressline2" => 'billing_address_2',
		"billing_city" => 'billing_city',
		"billing_county" => 'billing_state',
		"billing_eircode" =>'billing_postcode',
		"delivery_company" => 'shipping_company',
		"delivery_addressline1" =>'shipping_address_1',
		"delivery_addressline2" =>'shipping_address_2',
		"delivery_city" =>'shipping_city',
		"delivery_county" =>'shipping_state',
		"delivery_eircode" =>'shipping_postcode',				
		"created_date"=>date('Y-m-d H:i:s'),
	));
}

function plugin_remove_database() {
     global $wpdb;
     $table_name= $wpdb->prefix."autoaddress";	
     $sql = "DROP TABLE IF EXISTS $table_name";
     $wpdb->query($sql);
     delete_option("my_plugin_db_version");
} 

?>