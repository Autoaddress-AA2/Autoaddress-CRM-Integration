<?php
/*
Plugin Name: Autoaddress address lookup plugin
Plugin URI: https://www.autoaddress.ie/support/developer-centre/integrations/
Description: It Embeds Autoaddress's address lookup contact text field to your site. It is fast and simple way to capture addresses and Eircodes.
Version: 1.0
Author: Autoaddress
Author URI: https://www.autoaddress.ie
*/
include_once('DBP_db_file.php');
  
global $my_plugin_db_version;
$my_plugin_db_version = "1.0";

function jquery_add_inline() {
    wp_add_inline_script( 'jquery-core', '$ = jQuery;' );
}
add_action( 'wp_enqueue_scripts', 'jquery_add_inline' );
  
function custom_autoaddress_enqueue_style() {
	wp_enqueue_style('autoaddressstylesheet', "https://api.autoaddress.ie/2.0/control/css/autoaddress.min.css");
	wp_enqueue_script('autoaddressscript2', "https://api.autoaddress.ie/2.0/control/js/jquery.autoaddress.min.js",'', '', true);
	wp_enqueue_script('autoaddressscript3', "https://sites.autoaddress.ie/Wordpress/autoaddress_script.js",'', '', true);	
	wp_enqueue_script('autoaddressscript4', "https://sites.autoaddress.ie/Wordpress/script.js",'', '', true);	
	wp_enqueue_style('autoaddressstylesheet2', "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css");	
}
 
add_action ( 'wp_enqueue_scripts', 'custom_autoaddress_enqueue_style' );
//add_filter( 'plugin_action_links', 'settings_link');
add_action ( 'admin_menu', 'add_admin_page');
add_shortcode( 'autoaddress_addresslookup_billing', 'cf_shortcode_billing' );
add_shortcode( 'autoaddress_addresslookup_shipping', 'cf_shortcode_delivery' );
register_activation_hook(__FILE__,'table_creator');
register_uninstall_hook( __FILE__, 'plugin_remove_database' );
add_filter( 'woocommerce_checkout_fields' , 'add_autoaddress_controller_billing' );
add_filter( 'woocommerce_checkout_fields' , 'add_autoaddress_controller_delivery' );

function add_autoaddress_controller_billing( $fields ) {
    
	// Add New Billing Fields
    $fields['billing']['PreAAControl'] = array(
	'label'     => 'Address Lookup',
	'placeholder'   =>'Address Lookup',
	'required'  => true,
	'id' => 'AAControl1',
	'class'     => array('form-row'),
	'clear'     => true,
	'required' => false,
	'priority'  => $fields['billing']['billing_country']['priority'] + 5,
	);
 
	return $fields;
}

function add_autoaddress_controller_delivery( $fields ) {
    
	// Add New Delivery Fields	
    $fields['shipping']['PreAAControl1'] = array(
	'label'     => 'Address Lookup',
	'placeholder'   =>'Address Lookup',
	'required'  => true,
	'id' => 'AAControl2',
	'class'     => array('form-row'),
	'clear'     => true,
	'required' => false,		
	'priority'  => $fields['shipping']['shipping_country']['priority'] + 5,
	);
 
	return $fields;
}

function html_billing_form_code() {
	
	echo '<div style="margin:10px;">';
	
	global $wpdb;
	$table_name= $wpdb->prefix."autoaddress";	
	$DBP_results = $wpdb->GET_ROW("SELECT * FROM $table_name ORDER BY created_date DESC LIMIT 1");
	
	echo '</div id="hidden_field">';
	echo '<textarea id="txt_billing_profile" style="display:none;" rows="1" cols="50">'.$DBP_results->add_profile.'</textarea>' ;
	echo '<textarea id="txt_billing_lic" style="display:none;" rows="1" cols="50">'.$DBP_results->lic_key.'</textarea>' ;
	
	echo '<textarea id="txt_billing_company" style="display:none;" rows="1" cols="50">'.$DBP_results->billing_company.'</textarea>' ;
	echo '<textarea id="txt_billing_addressline1" style="display:none;" rows="1" cols="50">'.$DBP_results->billing_addressline1.'</textarea>' ;
	echo '<textarea id="txt_billing_addressline2" style="display:none;" rows="1" cols="50">'.$DBP_results->billing_addressline2.'</textarea>' ;
	echo '<textarea id="txt_billing_city" style="display:none;" rows="1" cols="50">'.$DBP_results->billing_city.'</textarea>' ;
	echo '<textarea id="txt_billing_county" style="display:none;" rows="1" cols="50">'.$DBP_results->billing_county.'</textarea>' ;
	echo '<textarea id="txt_billing_eircode" style="display:none;" rows="1" cols="50">'.$DBP_results->billing_eircode.'</textarea>' ;
	
	echo'</div>';		
}

function html_delivery_form_code() {
	
	echo '<div style="margin:10px;">';
	
	global $wpdb;
	$table_name= $wpdb->prefix."autoaddress";	
	$DBP_results = $wpdb->GET_ROW("SELECT * FROM $table_name ORDER BY created_date DESC LIMIT 1");
	
	echo '</div id="hidden_field">';
	echo '<textarea id="txt_delivery_profile" style="display:none;" rows="1" cols="50">'.$DBP_results->add_profile.'</textarea>' ;
	echo '<textarea id="txt_delivery_lic" style="display:none;" rows="1" cols="50">'.$DBP_results->lic_key.'</textarea>' ;
	
	echo '<textarea id="txt_delivery_company" style="display:none;" rows="1" cols="50">'.$DBP_results->delivery_company.'</textarea>' ;
	echo '<textarea id="txt_delivery_addressline1" style="display:none;" rows="1" cols="50">'.$DBP_results->delivery_addressline1.'</textarea>' ;
	echo '<textarea id="txt_delivery_addressline2" style="display:none;" rows="1" cols="50">'.$DBP_results->delivery_addressline2.'</textarea>' ;
	echo '<textarea id="txt_delivery_city" style="display:none;" rows="1" cols="50">'.$DBP_results->delivery_city.'</textarea>' ;
	echo '<textarea id="txt_delivery_county" style="display:none;" rows="1" cols="50">'.$DBP_results->delivery_county.'</textarea>' ;
	echo '<textarea id="txt_delivery_eircode" style="display:none;" rows="1" cols="50">'.$DBP_results->delivery_eircode.'</textarea>' ;
	
	echo'</div>';		
}

function cf_shortcode_billing() {
	ob_start();	
	html_billing_form_code();
	return ob_get_clean();
}

function cf_shortcode_delivery() {
	ob_start();
	html_delivery_form_code();
	return ob_get_clean();
}

function add_admin_page()
{
	add_menu_page('Autoaddress', 'Autoaddress', 'manage_options', 'autoaddress_plugin', 'admin_index', 'dashicons-location', 5);	 
}

function admin_index()
{
	require_once plugin_dir_path(__FILE__).'setting-page.php';  
}

function settings_link( $links )
{
	$settings_link='<a href="admin.php?page=autoaddress_plugin">Settings</a>';
	array_push($links,$settings_link); 
	return $links;
}
?>
